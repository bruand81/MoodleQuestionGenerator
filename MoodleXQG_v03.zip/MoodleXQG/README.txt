Moodle XML Question Generator, (C) 2019-2020 Kosaku Nagasaka (Kobe University)

The current version is 0.3.

This tool is distributed under CC BY-SA 4.0 
(see https://creativecommons.org/licenses/by-sa/4.0/ ).

The examples are the following jupyter notebooks in this folder:
- how_to_use_package.ipynb
- how_to_use_graph.ipynb
- how_to_use_urllib.ipynb
- how_to_use_qbank.ipynb

Note: This library was supported by JSPS KAKENHI Grant Number 18K02941.
